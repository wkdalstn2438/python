from pieces import Pawn, Queen, Rook, Bishop, Knight
from board import index_to_algebra


def handle_promotion(game, x, y):
    piece = game.board.grid[x][y]
    if not isinstance(piece, Pawn):
        return

    final_rank = 7 if piece.color == 'white' else 0
    if y != final_rank:
        return

    while True:
        choice = input("Promote to (Q, R, B, N): ").strip().upper()
        if choice in ('Q', 'R', 'B', 'N'):
            break
        print("❌ Invalid choice. Choose from Q, R, B, N.")

    promotion_map = {
        'Q': Queen,
        'R': Rook,
        'B': Bishop,
        'N': Knight
    }
    promoted_piece = promotion_map[choice](piece.color)
    game.board.grid[x][y] = promoted_piece

    print(f"{game.turn}'s pawn promoted to {choice} at {index_to_algebra(x, y)}!")
