from pieces import Pawn


def is_en_passant(game, piece, x1, y1, x2, y2):

    if not isinstance(piece, Pawn):
        return False

    direction = 1 if piece.color == 'white' else -1
    last_move = game.last_move
    if not last_move:
        return False

    (px1, py1), (px2, py2), p = last_move

    # 상대가 바로 직전에 두 칸 이동한 폰이어야 함
    if not isinstance(p, Pawn):
        return False
    if p.color == piece.color:
        return False
    if abs(px1 - x1) != 1 or px2 != x2:
        return False
    if py2 != y1:
        return False
    if py1 + 2 * direction != py2:
        return False
    if y2 != y1 + direction:
        return False

    return True


def apply_en_passant(game, x1, y1, x2, y2):
    direction = 1 if game.turn == 'white' else -1
    game.board.grid[x2][y2] = game.board.grid[x1][y1]  # 이동
    game.board.grid[x1][y1] = None                     # 시작칸 비우기
    game.board.grid[x2][y2 - direction] = None         # 상대 폰 제거

    print(f"⚔️ En Passant at {x2},{y2}!")
