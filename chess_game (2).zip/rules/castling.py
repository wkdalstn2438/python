from pieces import King, Rook


def make_move(game, x1, y1, x2, y2):
    piece = game.board.grid[x1][y1]
    if isinstance(piece, King):
        game.king_moved[piece.color] = True
    elif isinstance(piece, Rook):
        if x1 == 0:
            game.rook_moved[piece.color]['queenside'] = True
        elif x1 == 7:
            game.rook_moved[piece.color]['kingside'] = True

    game.board.grid[x2][y2] = piece
    game.board.grid[x1][y1] = None


def rank_for(color):
    return 0 if color == 'white' else 7


def can_castle(board, king_moved, rook_moved, color, kingside):
    y = rank_for(color)
    row = [board.grid[x][y] for x in range(8)]

    if king_moved[color]:
        return False

    rook_side = 'kingside' if kingside else 'queenside'
    if rook_moved[color][rook_side]:
        return False

    empty_between = [5, 6] if kingside else [1, 2, 3]
    return all(row[x] is None for x in empty_between)


def perform_castling(board, king_moved, rook_moved, color, kingside):
    y = rank_for(color)
    row = board.grid

    rook_from, rook_to, king_to = (7, 5, 6) if kingside else (0, 3, 2)

    king = row[4][y]
    rook = row[rook_from][y]

    row[king_to][y] = king
    row[rook_to][y] = rook
    row[4][y] = None
    row[rook_from][y] = None

    king_moved[color] = True
    rook_side = 'kingside' if kingside else 'queenside'
    rook_moved[color][rook_side] = True

    print(f"♖♔ {color} castled {rook_side}!")


def handle_castling_input(game, kingside):
    x1 = 4
    y1 = rank_for(game.turn)
    x2 = 6 if kingside else 2
    game.move(x1, y1, x2, y1)


def handle_castling(game, piece, x1, y1, x2, y2):
    if isinstance(piece, King) and abs(x2 - x1) == 2 and y1 == y2:
        if can_castle(game.board, game.king_moved, game.rook_moved, game.turn, kingside=(x2 > x1)):
            perform_castling(game.board, game.king_moved, game.rook_moved, game.turn, kingside=(x2 > x1))
            game.switch_turn()
            return True
        else:
            print("❌ Cannot castle")
            return True
    return False
