from pieces import Pawn, Knight, Bishop, Rook, Queen, King


# 좌표 변환 유틸
def algebra_to_index(pos: str):
    file = pos[0].lower()
    rank = int(pos[1])
    x = ord(file) - ord('a')
    y = rank - 1
    return x, y


def index_to_algebra(x: int, y: int):
    return f"{chr(ord('a') + x)}{y + 1}"


class Board:
    def __init__(self):
        self.grid = [[None for _ in range(8)] for _ in range(8)]
        self.setup()

    def setup(self):
        # # # 기본 기물 순서
        # piece_order = [Rook, Knight, Bishop, Queen, King, Bishop, Knight, Rook]
        #
        # # 1, 8랭크: 백과 흑 기물 배치
        # for x, piece_cls in enumerate(piece_order):
        #     self.grid[x][0] = piece_cls('white')  # 1 rank
        #     self.grid[x][7] = piece_cls('black')  # 8 rank
        #
        # # 2, 7랭크: 폰 배치
        # for x in range(8):
        #     self.grid[x][1] = Pawn('white')  # 2 rank
        #     self.grid[x][6] = Pawn('black')  # 7 rank

        # 백 폰: e5
        self.grid[4][1] = Pawn('white')  # e5

        # 흑 폰:
        self.grid[3][3] = Pawn('black')  # d5


    def display(self):
        print("  a b c d e f g h")
        for y in reversed(range(8)):
            row = f"{y+1} "
            for x in range(8):
                piece = self.grid[x][y]
                row += piece.symbol() if piece else '.'
                row += ' '
            print(row)
        print()

    def in_bounds(self, x, y):
        return 0 <= x < 8 and 0 <= y < 8
