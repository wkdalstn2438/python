from .base import Piece


class King(Piece):
    def symbol(self):
        return 'K' if self.color == 'white' else 'k'

    def valid_moves(self, board, x, y):
        directions = [(-1, -1), (-1, 0), (-1, 1),
                      (0,  -1),          (0,  1),
                      (1,  -1), (1,  0), (1,  1)]
        moves = []
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if board.in_bounds(nx, ny):
                target = board.grid[nx][ny]
                if target is None or target.color != self.color:
                    moves.append((nx, ny))

        # 캐슬링용 임시 허용 (검사는 Game에서 진행됨)
        if self.color == 'white' and (x, y) == (4, 0):
            moves.extend([(6, 0), (2, 0)])  # g1, c1
        elif self.color == 'black' and (x, y) == (4, 7):
            moves.extend([(6, 7), (2, 7)])  # g8, c8

        return moves