from .base import Piece


class Bishop(Piece):
    def symbol(self):
        return 'B' if self.color == 'white' else 'b'

    def valid_moves(self, board, x, y):
        moves = []
        directions = [(-1, -1), (-1, 1), (1, -1), (1, 1)]  # 좌하, 좌상, 우하, 우상

        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            while board.in_bounds(nx, ny):
                target = board.grid[nx][ny]
                if target is None:
                    moves.append((nx, ny))
                elif target.color != self.color:
                    moves.append((nx, ny))
                    break  # 적 기물 있으면 거기까지 이동하고 종료
                else:
                    break  # 아군 기물이면 막힘
                nx += dx
                ny += dy

        return moves