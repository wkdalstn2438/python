from .base import Piece


class Knight(Piece):
    def symbol(self):
        return 'N' if self.color == 'white' else 'n'
# 현재 위치에서 이동할수있는 칸[리스트]를 넘겨주는 함수
    def valid_moves(self, board, x, y):
        moves = []
        directions = [
            (-2, -1), (-2, 1),
            (-1, -2), (-1, 2),
            (1, -2),  (1, 2),
            (2, -1),  (2, 1)
        ]

        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if board.in_bounds(nx, ny):
                target = board.grid[nx][ny]
                if target is None or target.color != self.color:
                    moves.append((nx, ny))

        return moves