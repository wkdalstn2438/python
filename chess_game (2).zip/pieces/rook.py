from .base import Piece


class Rook(Piece):
    def symbol(self):
        return 'R' if self.color == 'white' else 'r'
    # 조건 1: 상대기물이 있으면 그 위치까지만 이동 가능
    # 조건 2: 우리팀 기물이 있으면 그 앞까지만 이동 가능
    def valid_moves(self, board, x, y):
        moves = []
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # 좌, 우, 하, 상

        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            while board.in_bounds(nx, ny):
                target = board.grid[nx][ny]
                if target is None:
                    moves.append((nx, ny))
                elif target.color != self.color:
                    moves.append((nx, ny))
                    break  # 상대 기물은 잡을 수 있지만 그 이후는 못 감
                else:
                    break  # 아군 기물 있으면 거기서 멈춤
                nx += dx
                ny += dy

        return moves