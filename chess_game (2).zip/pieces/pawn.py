from .base import Piece


class Pawn(Piece):
    def symbol(self):
        return 'P' if self.color == 'white' else 'p'

    def valid_moves(self, board, x, y):
        moves = []
        direction = 1 if self.color == 'white' else -1
        start_row = 1 if self.color == 'white' else 6

        # 한 칸 전진
        if board.in_bounds(x, y + direction) and board.grid[x][y + direction] is None:
            moves.append((x, y + direction))

            # 첫 수일 때 두 칸 전진
            if y == start_row and board.grid[x][y + 2 * direction] is None:
                moves.append((x, y + 2 * direction))

        # 대각선 공격
        for dx in [-1, 1]:
            nx, ny = x + dx, y + direction
            if board.in_bounds(nx, ny):
                target = board.grid[nx][ny]
                if target and target.color != self.color:
                    moves.append((nx, ny))

        return moves