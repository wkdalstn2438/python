from board import Board, algebra_to_index
from pieces import King
from rules import castling
from rules.promotion import handle_promotion
from rules.en_passant import is_en_passant, apply_en_passant


class Game:
    def __init__(self):
        self.board = Board()
        self.turn = 'white'
        self.running = True
        self.king_moved = {'white': False, 'black': False}
        self.rook_moved = {
            'white': {'kingside': False, 'queenside': False},
            'black': {'kingside': False, 'queenside': False}
        }
        self.last_move = None

    def start(self):
        while self.running:
            self.board.display()
            print(f"{self.turn}'s turn. (e.g., e2 e4)")
            try:
                user_input = input("Move: ").strip().upper()
                if user_input in ('0-0', 'O-O'):
                    castling.handle_castling_input(self, kingside=True)
                    continue
                elif user_input in ('0-0-0', 'O-O-O'):
                    castling.handle_castling_input(self, kingside=False)
                    continue

                pos1, pos2 = user_input.split()
                x1, y1 = algebra_to_index(pos1)
                x2, y2 = algebra_to_index(pos2)
                self.move(x1, y1, x2, y2)
            except Exception:
                print("❌ Invalid input format. Use 'e2 e4' or '0-0'")

    def move(self, x1, y1, x2, y2):
        if not self.board.in_bounds(x1, y1) or not self.board.in_bounds(x2, y2):
            print("❌ Invalid coordinates")
            return

        piece = self.board.grid[x1][y1]
        if not piece:
            print("❌ No piece at start position")
            return
        if piece.color != self.turn:
            print("❌ Not your turn")
            return

        valid = piece.valid_moves(self.board, x1, y1)
        if (x2, y2) not in valid:
            print("❌ Invalid move for that piece")
            return

        if castling.handle_castling(self, piece, x1, y1, x2, y2):
            return

        if is_en_passant(self, piece, x1, y1, x2, y2):
            apply_en_passant(self, x1, y1, x2, y2)
            self.last_move = ((x1, y1), (x2, y2), piece)
            self.check_win(x2, y2)
            self.switch_turn()
            return

        castling.make_move(self, x1, y1, x2, y2)
        handle_promotion(self, x2, y2)
        self.last_move = ((x1, y1), (x2, y2), piece)
        self.check_win(x2, y2)
        self.switch_turn()

    def check_win(self, x, y):
        target = self.board.grid[x][y]
        if isinstance(target, King) and target.color != self.turn:
            print(f"🏁 {self.turn} wins! {target.color} King captured.")
            self.running = False

    def switch_turn(self):
        self.turn = 'black' if self.turn == 'white' else 'white'
