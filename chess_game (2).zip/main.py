from game import Game

# 실행
if __name__ == "__main__":
    Game().start()

