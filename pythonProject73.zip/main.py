from googleapiclient.discovery import build

api_key = "AIzaSyCo-19bFtqmg2c_GiQ_DuHxc-212vXuBaM"
youtube = build('youtube', 'v3', developerKey=api_key)

titles = []
next_page_token = None

while len(titles) < 200:
    request = youtube.search().list(
        part="snippet",
        q="음악",
        type="video",
        maxResults=50,
        pageToken=next_page_token
    )
    response = request.execute()

    for item in response["items"]:
        titles.append(item["snippet"]["title"])
        if len(titles) >= 200:
            break

    next_page_token = response.get("nextPageToken")
    if not next_page_token:
        break

# 결과 확인
for i, title in enumerate(titles):
    print(f"{i + 1}. {title}")