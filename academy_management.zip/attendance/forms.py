from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, Student

class StudentSignupForm(UserCreationForm):
    age = forms.IntegerField(label="나이")
    address = forms.CharField(label="주소")
    first_name = forms.CharField(label='이름')
    school = forms.CharField(label="학교")
    career_plan = forms.CharField(label="진로 계획", required=False, widget=forms.Textarea)
    emergency_contact = forms.CharField(label="비상연락망")

    class Meta:
        model = CustomUser
        fields = ('username', 'password1', 'password2', 'age', 'address', 'school', 'career_plan', 'emergency_contact')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.first_name = self.cleaned_data['first_name']
        if commit:
            user.save()
            student = Student.objects.create(
                user=user,
                age=self.cleaned_data['age'],
                first_name = self.cleaned_data['first_name'],
                address=self.cleaned_data['address'],
                school=self.cleaned_data['school'],
                career_plan=self.cleaned_data['career_plan'],
                emergency_contact=self.cleaned_data['emergency_contact'],
                is_approved=False  # 가입 시 대기 상태
            )
        return user


class StudentProfileForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['age', 'first_name', 'address', 'school', 'career_plan', 'emergency_contact']
        labels = {
            'age': '나이',
            'first_name': '이름',
            'address': '주소',
            'school': '학교',
            'career_plan': '진로 계획',
            'emergency_contact': '비상연락망',
        }
