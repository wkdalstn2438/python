from django.test import TestCase

# Create your tests here.
from models import Attendance
a = Attendance.objects.first()
print(a.student)  # CustomUser 객체로 나와야 함
print(a.student.username)
print(a.student.first_name)
