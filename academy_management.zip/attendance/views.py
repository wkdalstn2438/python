from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Attendance,Class
from django.http import HttpResponseForbidden
from django.contrib.auth import authenticate, login
from django.utils import timezone
from .forms import StudentProfileForm
  
def main_page(request):
    # 메인페이지에서 로그인 처리
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)  # 자격증명 인증함수 => User/None
        if user is not None:
            login(request, user)
            return redirect("main_page")
        else:
            return render(request, "attendance/index.html", {
                "login_error": "아이디 또는 비밀번호가 올바르지 않습니다."
            })

    return render(request, "attendance/index.html")



@login_required
def student_attendance_view(request):             # 학생 출격 확인
    if not hasattr(request.user, 'student'):
        return HttpResponseForbidden("학생만 접근할 수 있습니다.")

    student = request.user
    sort_order = request.GET.get('sort', 'desc')  # 기본값: 최근순  

    
    attendance_records = Attendance.objects.filter(student=student)
    if sort_order == 'asc':
        attendance_records = attendance_records.order_by('class_attended__start_time')
    else:
        attendance_records = attendance_records.order_by('-class_attended__start_time')
    # 🔎 필터 처리
    class_name = request.GET.get('class_name')
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    if class_name:
        attendance_records = attendance_records.filter(class_attended__name=class_name)
    if start_date:
        attendance_records = attendance_records.filter(date__gte=start_date)
    if end_date:
        attendance_records = attendance_records.filter(date__lte=end_date)

    # 전체 수업 리스트 가져오기 (드롭다운용)
    classes = Class.objects.filter(students=student)

    return render(request, 'attendance/student_attendance.html', {
        'attendance_records': attendance_records,
        'classes': classes,
        'selected_class': class_name,
        'start_date': start_date,
        'end_date': end_date,
    })


@login_required
def student_profile_edit(request):
    if not hasattr(request.user, 'student'):
        return HttpResponseForbidden("학생만 접근할 수 있습니다.")

    student = request.user.student
    saved = False

    if request.method == 'POST':
        form = StudentProfileForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            saved = True
    else:
        form = StudentProfileForm(instance=student)

    return render(request, 'attendance/student_profile_edit.html', {
        'form': form,
        'saved': saved
    })




@login_required
def teacher_attendance_manage_view(request):
    if not hasattr(request.user, 'teacher'):
        return HttpResponseForbidden("선생님만 접근할 수 있습니다.")

    # 예시: 선생님이 담당하는 수업의 출결 리스트 불러오기
    teacher = request.user.teacher
    classes = teacher.class_set.all()
    attendance_records = Attendance.objects.filter(class_attended__in=classes)
    sort_order = request.GET.get('sort', 'desc')  # 기본값: 최근순  
    if sort_order == 'asc':
        attendance_records = attendance_records.order_by('class_attended__start_time')
    else:
        attendance_records = attendance_records.order_by('-class_attended__start_time')
    # 🔎 필터 처리
    class_name = request.GET.get('class_name')
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    if class_name:
        attendance_records = attendance_records.filter(class_attended__name=class_name)
    if start_date:
        attendance_records = attendance_records.filter(date__gte=start_date)
    if end_date:
        attendance_records = attendance_records.filter(date__lte=end_date)

    # 전체 수업 리스트 가져오기 (드롭다운용)

    return render(request, 'attendance/student_attendance.html', {
        'attendance_records': attendance_records,
        'classes': classes,
        'selected_class': class_name,
        'start_date': start_date,
        'end_date': end_date,
    })
    
    
def award_detail(request, award_id):
    award_data = {
        1: "2023 전국 알고리즘 대회 대상 수상작",
        2: "2023 청소년 코딩 경진대회 최우수상 수상작",
        3: "2022 서울 코딩 페스티벌 금상 수상작",
        4: "2022 창의적 문제해결 경진대회 은상 수상작",
    }
    award_name = award_data.get(award_id, "수상 경력 상세 없음")
    return render(request, 'attendance/award_detail.html', {'award_name': award_name})

from .forms import StudentSignupForm

def student_signup(request):
    if request.method == 'POST':
        form = StudentSignupForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')  # 가입 완료 페이지로 이동
    else:
        form = StudentSignupForm()

    return render(request, 'attendance/student_signup.html', {'form': form})


import requests
import json
from django.conf import settings

def search_address(request):
    keyword = request.GET.get('q', '')

    if not keyword:
        return render(request, 'attendance/address_search_form.html')

    api_key = settings.ADDRESS_API_KEY  # 안전하게 불러온 키 사용
    url = f"https://www.juso.go.kr/addrlink/addrLinkApiJsonp.do?confmKey={api_key}&currentPage=1&countPerPage=10&keyword={keyword}&resultType=json"

    response = requests.get(url)
    data = response.text.lstrip('(').rstrip(')')  # JSONP 대응
    result = json.loads(data)

    return render(request, 'attendance/address_search_result.html', {'addresses': result['results']['juso']})


def search_school(request):
    keyword = request.GET.get('q', '')

    if not keyword:
        return render(request, 'attendance/school_search_form.html')

    api_url = f"https://open.neis.go.kr/hub/schoolInfo?KEY={settings.SCHOOL_API_KEY}&Type=json&pIndex=1&pSize=20&SCHUL_NM={keyword}"
    response = requests.get(api_url)
    data = response.json()

    schools = data.get('schoolInfo', [])[1]['row'] if 'schoolInfo' in data else []

    return render(request, 'attendance/school_search_result.html', {'schools': schools})

from django.http import HttpResponse
from django.contrib.auth import get_user_model

User = get_user_model()

def check_username(request):
    username = request.GET.get('username')
    if not username:
        return HttpResponse("아이디가 전달되지 않았습니다.")

    if User.objects.filter(username=username).exists():
        return HttpResponse("이미 사용 중인 아이디입니다.")
    else:
        return HttpResponse("사용 가능한 아이디입니다.")

@login_required
def mark_attendance_view(request, class_id):
    teacher = request.user.teacher
    class_obj = get_object_or_404(Class, id=class_id, teacher=teacher)
    students = class_obj.students.all()

    if request.method == 'POST':
        for student in students:
            status = request.POST.get(f'status_{student.id}')
            if status:  # 선택된 경우에만 기록
                Attendance.objects.update_or_create(
                    student=student,
                    class_attended=class_obj,
                    date=timezone.now().date(),  # 오늘 날짜 기준
                    defaults={
                        'status': status,
                        'timestamp': timezone.now(),
                    }
                )
        return redirect('teacher_attendance_manage')  # 출결 관리 페이지로 이동

    return render(request, 'attendance/mark_attendance.html', {
        'class_obj': class_obj,
        'students': students,
    })

@login_required
def select_class_for_attendance_view(request):
    teacher = request.user.teacher
    classes = Class.objects.filter(teacher=teacher)

    if request.method == 'POST':
        class_id = request.POST.get('class_id')
        if class_id:
            return redirect('mark_attendance', class_id=class_id)

    return render(request, 'attendance/select_class_for_attendance.html', {
        'classes': classes
    })