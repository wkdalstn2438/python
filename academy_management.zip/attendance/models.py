from django.contrib.auth.models import AbstractUser, Group, Permission
from django.db import models


# ✅ 1. 사용자 모델 (확장)
class CustomUser(AbstractUser):
    groups = models.ManyToManyField(Group, related_name="customuser_groups", blank=True)
    user_permissions = models.ManyToManyField(Permission, related_name="customuser_permissions", blank=True)

    class Meta:
        verbose_name = "사용자"
        verbose_name_plural = "사용자 목록"

    def __str__(self):
        return self.username


# ✅ 2. 학생 모델
class Student(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    student_id = models.CharField(max_length=20, unique=True,default='')  # 🔸 오류 해결 핵심!
    age = models.PositiveIntegerField(default=0)
    first_name = models.CharField(max_length=20, default='')
    address = models.CharField(max_length=200, default='')
    school = models.CharField(max_length=100, default='')
    career_plan = models.TextField(blank=True)
    emergency_contact = models.CharField(max_length=20, default='')
    is_approved = models.BooleanField(default=False)

    class Meta:
        verbose_name = "학생"
        verbose_name_plural = "학생 목록"

    def __str__(self):
        return f"학생: {self.user.username}"


# ✅ 3. 선생님 모델
class Teacher(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    subject = models.CharField(max_length=50)

    class Meta:
        verbose_name = "선생님"
        verbose_name_plural = "선생님 목록"

    def __str__(self):
        return f"선생님: {self.user.username}"


# ✅ 4. 수업 모델
class Class(models.Model):
    name = models.CharField(max_length=100)
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    students = models.ManyToManyField(CustomUser, related_name="classes")  # 🔸 CustomUser로 설정
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()

    class Meta:
        verbose_name = "수업"
        verbose_name_plural = "수업 목록"

    def __str__(self):
        return f"{self.name} ({self.teacher.user.username})"


# ✅ 5. 출결 모델
class Attendance(models.Model):
    STATUS_CHOICES = [
        ('present', '출석'),
        ('late', '지각'),
        ('absent', '결석'),
    ]
    student = models.ForeignKey(CustomUser, on_delete=models.CASCADE)  # 🔸 학생/선생님 수강 허용
    class_attended = models.ForeignKey(Class, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='present')
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "출결"
        verbose_name_plural = "출결 목록"

    def __str__(self):
        return f"{self.student.username} - {self.class_attended.name} - {self.get_status_display()} ({self.date})"


# ✅ 6. 학원 정보 모델
class AcademyInfo(models.Model):
    name = models.CharField(max_length=100, default='코딩학원')
    phone = models.CharField(max_length=20)
    address = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    logo = models.ImageField(upload_to='academy_logo/', blank=True)

    def __str__(self):
        return self.name
