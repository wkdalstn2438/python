from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, get_user_model
from django.contrib import messages
from django.conf import settings
from .forms import StudentSignupForm
from django.http import JsonResponse
import requests
import json
from main.views import index


def student_signup(request):
    if request.method == 'POST':
        form = StudentSignupForm(request.POST)
        if form.is_valid():
            print("폼 유효함") 
            user = form.save()
            login(request, user)
            return redirect('main:main_page')  
        else:
            print("폼 오류", form.errors)
    else:
        form = StudentSignupForm()
    return render(request, 'profiles/student_signup.html', {'form': form})




# 아이디 중복확인 
def checkDuplicated(request):
    username = request.GET.get('username')
    print(f"DEBUG username: {username}")
    if not username:
        return JsonResponse({'error': '아이디가 전달되지 않았습니다.'}, status=400)

    exists = get_user_model().objects.filter(username=username).exists()
    return JsonResponse({'result': not exists})


    
# 주소 api 연결
def search_address(request):
    keyword = request.GET.get('q', '')

    if not keyword:
        return render(request, 'profiles/address_search_popup.html')

    api_key = settings.ADDRESS_API_KEY  
    api_key = "devU01TX0FVVEgyMDI1MDUwNDE3NDgyMTExNTcxODk="
    print(f"apiKey: {api_key}")
    print(f"keyword: {keyword}")
    url = f"https://www.juso.go.kr/addrlink/addrLinkApiJsonp.do?confmKey={api_key}&currentPage=1&countPerPage=50&keyword={keyword}&resultType=json"
    response = requests.get(url)
    data = response.text.lstrip('(').rstrip(')')
    result = json.loads(data)['results']['juso']
    return render(request, 'profiles/address_search_popup.html', {'addresses': result})

# 학교 api 연결 
def search_school(request):
    keyword = request.GET.get('q', '')
    if not keyword:
        return render(request, 'profiles/school_search_popup.html')
    api_key = settings.SCHOOL_API_KEY
    print(f"apiKey: {api_key}")
    api_url = f"https://open.neis.go.kr/hub/schoolInfo?KEY={settings.SCHOOL_API_KEY}&Type=json&pIndex=1&pSize=20&SCHUL_NM={keyword}"
    response = requests.get(api_url)
    data = response.json()
    print(data)
    schools = data.get('schoolInfo', [])[1]['row'] if 'schoolInfo' in data else []

    return render(request, 'profiles/school_search_popup.html', {'schools': schools})

