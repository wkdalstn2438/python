from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.

class CustomUser(AbstractUser):
    is_student = models.BooleanField(default=False)
    is_teacher = models.BooleanField(default=False)

    def __str__(self):
        return self.username
    
class Student(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    student_id = models.CharField(max_length=20, unique=True)
    age = models.PositiveIntegerField()
    name = models.CharField(max_length=50)
    phone = models.CharField(max_length=11)
    emergency_contact = models.CharField(max_length=11)
    address = models.CharField(max_length=200)
    subaddress = models.CharField(max_length=200, blank=True)
    school = models.CharField(max_length=100)
    career_plan = models.TextField(blank=True)
    email = models.CharField(max_length=50)

    def __str__(self):
        return f"[학생] {self.name}"

class Teacher(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    name = models.CharField(max_length=50)
    expertise = models.CharField(max_length=100, blank=True)
    introduction = models.TextField(blank=True)

    def __str__(self):
        return f"[선생님] {self.name}"