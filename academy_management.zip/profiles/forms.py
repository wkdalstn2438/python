from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, Student

@staticmethod
def validate_digits_only(value):
    if not value.isdigit():
        raise forms.ValidationError("숫자만 입력해주세요.")
        

class StudentSignupForm(UserCreationForm):
    student_id = forms.CharField(label="학생 ID", max_length=20)
    age = forms.IntegerField(label="나이", min_value=1)
    name = forms.CharField(label="이름", max_length=50)
    phone = forms.CharField(label="번호", max_length=11, validators=[validate_digits_only])
    emergency_contact = forms.CharField(label="비상 연락처", max_length=11, validators=[validate_digits_only])
    address = forms.CharField(label="주소", max_length=200)
    subaddress = forms.CharField(label="상세 주소", max_length=200, required=False)
    school = forms.CharField(label="학교", max_length=100)
    email = forms.CharField(label="이메일", max_length=50)
    career_plan = forms.CharField(label="진로 계획", widget=forms.Textarea, required=False)
    

    class Meta(UserCreationForm.Meta):
        model = CustomUser
        fields = ("username", "password1", "password2")

        
    def save(self, commit=True):
        user = super().save(commit=False)
        user.is_student = True
        user.is_active = False  # 가입 후 관리자 승인 필요
        if commit:
            user.save()
            Student.objects.create(
                user=user,
                student_id=self.cleaned_data["student_id"],
                age=self.cleaned_data["age"],
                name=self.cleaned_data["name"],
                phone=self.cleaned_data["phone"],
                emergency_contact=self.cleaned_data["emergency_contact"],
                address=self.cleaned_data["address"],
                subaddress=self.cleaned_data.get("subaddress", ""),
                school=self.cleaned_data["school"],
                career_plan=self.cleaned_data.get("career_plan", ""),
                email=self.cleaned_data["email"]
            )
        return user
