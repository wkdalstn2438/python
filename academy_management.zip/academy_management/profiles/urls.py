from django.urls import path, include
from . import views

app_name = 'profiles'

urlpatterns = [
    path('signup/student/', views.student_signup, name='student_signup'),                     # 학생 회원가입입
    path('search_address/', views.search_address, name='search_address'),                     # 회원가입 주소 찾기기
    path('search_school/', views.search_school, name='search_school'),                        # 회원가입 학교 찾기
    path('checkduplicated/', views.checkDuplicated, name='checkDuplicated'),                   # 회원가입 아이디 중복확인
    path('', views.index, name='main_page'),
]
