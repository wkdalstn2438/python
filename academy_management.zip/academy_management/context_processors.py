from django.urls import reverse_lazy

def global_urls(request):
    return {
        'student_signup_url': reverse_lazy('profiles:student_signup'),
        'login_url': reverse_lazy('login'),
        'logout_url': reverse_lazy('logout'),
    }
