from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import logout
import os


def index(request):
    #academy_management/static/awards에 있는 이미지 불러오기
    awards_dir = os.path.join(settings.BASE_DIR, 'static', 'awards')
    award_files = []
    for file in os.listdir(awards_dir):
        if file.lower().endswith(('.png', '.jpg', '.jpeg', '.gif')):
            award_files.append(file)
            
    # 로그인 처리 과정
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('main_page')
        else:
            messages.error(request, '아이디 또는 비밀번호가 올바르지 않습니다.')
            return render(request, 'index.html', {'login_error': '아이디 또는 비밀번호가 올바르지 않습니다.'})
    return render(request, 'index.html',{'award_files': award_files})





# django에 있는 로그인 기능 연결
def user_logout(request):
    logout(request)
    return redirect('main_page')




