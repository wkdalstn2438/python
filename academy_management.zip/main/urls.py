from django.urls import path
from . import views

app_name = 'main'

urlpatterns = [
    path('', views.index, name='main_page'),
    path('logout/', views.user_logout, name='logout'),  # 로그아웃 URL 연결 
  
]
