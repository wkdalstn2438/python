from django.contrib import admin
from django.contrib.auth.admin import UserAdmin  # 🔹 UserAdmin 불러오기
from .models import CustomUser, Student, Teacher, Class, Attendance

# ✅ 사용자(User) 관리자 등록 (UserAdmin 사용 → 비밀번호 암호화 처리 포함)
@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    pass  # 기본 UserAdmin 설정 사용 (비밀번호 해시 포함)

# ✅ 학생 관리자
@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ("user", "student_id")

# ✅ 선생님 관리자
@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ("user", "subject")

# ✅ 수업 관리자
@admin.register(Class)
class ClassAdmin(admin.ModelAdmin):
    list_display = ("name", "teacher", "start_time", "end_time")

# ✅ 출결 관리자
@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ("student", "class_attended", "date", "status", "timestamp")
    list_filter = ("class_attended", "status", "date")
    search_fields = ("student__user__username", "class_attended__name")
