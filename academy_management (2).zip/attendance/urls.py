from django.urls import path
from .views import *

urlpatterns = [
    path('', main_page, name='main_page'),
    path('attendance/', student_attendance_view, name='student_attendance'),
    path('awards/<int:award_id>/', award_detail, name='award_detail'),

    path('signup/', student_signup, name='student_signup'),
    path('search_school/', search_school, name='search_school'),
    path('mypage/', student_profile_edit, name='student_profile_edit'),
    path('check_username/', check_username, name='check_username'),
    path('teacher/attendance/mark/', select_class_for_attendance_view, name='select_attendance_class'),
    path('teacher/attendance/mark/<int:class_id>/', mark_attendance_view, name='mark_attendance'),
    path('calendar/', calendar_view, name='calendar'),
    path('calendar/add_class/', add_class_view, name='add_class'),
    # urls.py
    path('class/<int:class_id>/', class_detail_view, name='class_detail'),
    path('class/<int:class_id>/edit/', edit_class_view, name='edit_class'),


]
